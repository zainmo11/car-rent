#include <iostream>

#include "FileManager.h"
#include "ProgramLoop.h"

int main() {

	ProgramLoop::run();
}